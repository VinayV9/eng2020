#eng2020

nodejs

native-script

side kick

##Development Setup

git clone ""

cd eng2020

npm install

##Running the app for local development

Open side-kick
select eng2020 folder
if you have android sdk installed you can choose local build
or choose colud build
To see the output connect your device through OTG cable or else use emulator.
Open developer options in your connected device and enable allow debugging.
Click run on device.
it will take 10 - 15 mins for the first time.
after project is builed you can see the output on your connected device.
you can change your code and see the changes in real time.

##Project Structure

app :

node_modules :

platforms :

hooks :

package.json :
