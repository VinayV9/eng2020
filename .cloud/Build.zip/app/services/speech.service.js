"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_texttospeech_1 = require("nativescript-texttospeech");
var nativescript_speech_recognition_1 = require("nativescript-speech-recognition");
var SpeechService = /** @class */ (function () {
    function SpeechService(tts, speech) {
        var _this = this;
        this.tts = tts;
        this.speech = speech;
        this.speechOptions = {
            locale: 'en-Us',
            onResult: function (transcription) {
                _this.textToSay = '';
                _this.textToSay = transcription.text;
                alert(transcription.text);
            }
        };
    }
    //text to speech
    SpeechService.prototype.textToSpeech = function (text) {
        this.ttsOptions = {
            text: text,
            finishedCallback: function (data) {
                console.log(data);
                console.log("i'm done");
            }
        };
        this.tts.speak(this.ttsOptions);
    };
    //sppech to text
    SpeechService.prototype.speechToText = function () {
        var _this = this;
        this.speech.available().then(function (result) { result ? _this.startListening() : alert('Speech recognization is not available'); }, function (err) { console.log(err); });
    };
    SpeechService.prototype.startListening = function () {
        this.speech.startListening(this.speechOptions).then(function () { console.log('started listing'); }, function (err) { console.log(err); });
    };
    SpeechService.prototype.stopListening = function () {
        this.speech.stopListening().then(function () { console.log('stopped listening'); }, function (err) { console.log(err); });
    };
    SpeechService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [nativescript_texttospeech_1.TNSTextToSpeech, nativescript_speech_recognition_1.SpeechRecognition])
    ], SpeechService);
    return SpeechService;
}());
exports.SpeechService = SpeechService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BlZWNoLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzcGVlY2guc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyQztBQUMzQyx1RUFBMEU7QUFDMUUsbUZBQTZIO0FBSTdIO0lBS0ksdUJBQW9CLEdBQW9CLEVBQVUsTUFBeUI7UUFBM0UsaUJBU0M7UUFUbUIsUUFBRyxHQUFILEdBQUcsQ0FBaUI7UUFBVSxXQUFNLEdBQU4sTUFBTSxDQUFtQjtRQUN2RSxJQUFJLENBQUMsYUFBYSxHQUFHO1lBQ3JCLE1BQU0sRUFBRSxPQUFPO1lBQ2YsUUFBUSxFQUFFLFVBQUMsYUFBNkM7Z0JBQ2hELEtBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO2dCQUNwQixLQUFJLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUM7Z0JBQ3BDLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDOUIsQ0FBQztTQUNKLENBQUE7SUFDTCxDQUFDO0lBRUQsZ0JBQWdCO0lBQ2hCLG9DQUFZLEdBQVosVUFBYSxJQUFJO1FBQ2IsSUFBSSxDQUFDLFVBQVUsR0FBRztZQUNkLElBQUksRUFBRSxJQUFJO1lBQ1YsZ0JBQWdCLEVBQUUsVUFBQyxJQUFJO2dCQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzFCLENBQUM7U0FDRixDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxnQkFBZ0I7SUFDaEIsb0NBQVksR0FBWjtRQUFBLGlCQUlDO1FBSEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQ3hCLFVBQUEsTUFBTSxJQUFNLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFBLENBQUMsQ0FBQyxLQUFLLENBQUMsdUNBQXVDLENBQUMsQ0FBQyxDQUFBLENBQUMsRUFDNUYsVUFBQSxHQUFHLElBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLENBQUMsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxzQ0FBYyxHQUFkO1FBQ0ksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FDakQsY0FBUSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQ3pDLFVBQUEsR0FBRyxJQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQzdCLENBQUM7SUFDTCxDQUFDO0lBRUQscUNBQWEsR0FBYjtRQUNHLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUM5QixjQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFBLENBQUMsRUFDMUMsVUFBQSxHQUFHLElBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLENBQUMsQ0FDNUIsQ0FBQztJQUNKLENBQUM7SUEvQ00sYUFBYTtRQUR6QixpQkFBVSxFQUFFO3lDQU1nQiwyQ0FBZSxFQUFrQixtREFBaUI7T0FMbEUsYUFBYSxDQWdEekI7SUFBRCxvQkFBQztDQUFBLEFBaERELElBZ0RDO0FBaERZLHNDQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IFROU1RleHRUb1NwZWVjaCwgU3BlYWtPcHRpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC10ZXh0dG9zcGVlY2hcIjtcclxuaW1wb3J0IHsgU3BlZWNoUmVjb2duaXRpb24sIFNwZWVjaFJlY29nbml0aW9uVHJhbnNjcmlwdGlvbiwgU3BlZWNoUmVjb2duaXRpb25PcHRpb25zfSBmcm9tIFwibmF0aXZlc2NyaXB0LXNwZWVjaC1yZWNvZ25pdGlvblwiO1xyXG5cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFNwZWVjaFNlcnZpY2Uge1xyXG4gICAgdGV4dFRvU2F5OiBzdHJpbmc7XHJcbiAgICB0dHNPcHRpb25zOiBTcGVha09wdGlvbnM7XHJcbiAgICBzcGVlY2hPcHRpb25zOiBTcGVlY2hSZWNvZ25pdGlvbk9wdGlvbnM7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSB0dHM6IFROU1RleHRUb1NwZWVjaCwgcHJpdmF0ZSBzcGVlY2g6IFNwZWVjaFJlY29nbml0aW9uKXtcclxuICAgICAgICB0aGlzLnNwZWVjaE9wdGlvbnMgPSB7XHJcbiAgICAgICAgbG9jYWxlOiAnZW4tVXMnLFxyXG4gICAgICAgIG9uUmVzdWx0OiAodHJhbnNjcmlwdGlvbjogU3BlZWNoUmVjb2duaXRpb25UcmFuc2NyaXB0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRleHRUb1NheSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50ZXh0VG9TYXkgPSB0cmFuc2NyaXB0aW9uLnRleHQ7XHJcbiAgICAgICAgICAgICAgICBhbGVydCh0cmFuc2NyaXB0aW9uLnRleHQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vdGV4dCB0byBzcGVlY2hcclxuICAgIHRleHRUb1NwZWVjaCh0ZXh0KXtcclxuICAgICAgICB0aGlzLnR0c09wdGlvbnMgPSB7XHJcbiAgICAgICAgICAgIHRleHQ6IHRleHQsXHJcbiAgICAgICAgICAgIGZpbmlzaGVkQ2FsbGJhY2s6IChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJpJ20gZG9uZVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIHRoaXMudHRzLnNwZWFrKHRoaXMudHRzT3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy9zcHBlY2ggdG8gdGV4dFxyXG4gICAgc3BlZWNoVG9UZXh0KCl7XHJcbiAgICAgICAgdGhpcy5zcGVlY2guYXZhaWxhYmxlKCkudGhlbihcclxuICAgICAgICAgICAgcmVzdWx0ID0+IHsgcmVzdWx0ID8gdGhpcy5zdGFydExpc3RlbmluZygpOiBhbGVydCgnU3BlZWNoIHJlY29nbml6YXRpb24gaXMgbm90IGF2YWlsYWJsZScpO30sXHJcbiAgICAgICAgICAgIGVyciA9PiB7IGNvbnNvbGUubG9nKGVycik7fSk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhcnRMaXN0ZW5pbmcoKXtcclxuICAgICAgICB0aGlzLnNwZWVjaC5zdGFydExpc3RlbmluZyh0aGlzLnNwZWVjaE9wdGlvbnMpLnRoZW4oXHJcbiAgICAgICAgICAoKSA9PiB7IGNvbnNvbGUubG9nKCdzdGFydGVkIGxpc3RpbmcnKTsgfSxcclxuICAgICAgICAgIGVyciA9PiB7IGNvbnNvbGUubG9nKGVycik7IH1cclxuICAgICAgICApO1xyXG4gICAgIH1cclxuXHJcbiAgICAgc3RvcExpc3RlbmluZygpe1xyXG4gICAgICAgIHRoaXMuc3BlZWNoLnN0b3BMaXN0ZW5pbmcoKS50aGVuKFxyXG4gICAgICAgICAgKCkgPT4geyBjb25zb2xlLmxvZygnc3RvcHBlZCBsaXN0ZW5pbmcnKTt9LFxyXG4gICAgICAgICAgZXJyID0+IHsgY29uc29sZS5sb2coZXJyKTt9XHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG59XHJcbiJdfQ==