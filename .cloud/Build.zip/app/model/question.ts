export interface Question {
    id: number;
    text: string;
    visims: any[];
}
