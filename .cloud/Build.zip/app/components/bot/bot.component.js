"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_texttospeech_1 = require("nativescript-texttospeech");
var nativescript_speech_recognition_1 = require("nativescript-speech-recognition");
var question_service_1 = require("../../services/question.service");
var router_1 = require("@angular/router");
var BotComponent = /** @class */ (function () {
    //create another control that increases or dcreases the timing and plays again
    //let increment or decrement be 10ms
    //play the sound also
    //find the sweetspot and set that value. Assume speechrate to be 1.0
    function BotComponent(tts, speech, questionService, route) {
        var _this = this;
        this.tts = tts;
        this.speech = speech;
        this.questionService = questionService;
        this.route = route;
        this.juliaImages = ['julia_angry.png', 'julia_tongue2_full.png', 'julia_eyes_closed.png', 'julia_eyes_close1.png', 'julia_eyes_close2.png', 'julia_eyes_lookleft.png', 'julia_eyes_quiz.png', 'julia_eyes_lookright.png', 'julia_mouth_narrow_w.png', 'julia_eyes_sad.png', 'julia_eyes_wow.png', 'julia_mouth_medium1.png', 'julia_full.png', 'julia_mouth_closed.png', 'julia_mouth_narrow_o.png', 'julia_mouth_narrow_u.png', 'julia_mouth_smile.png', 'julia_mouth_wide_f.png'];
        this.timing = 200;
        this.julia = '';
        this.speechOptions = {
            locale: 'en-Us',
            onResult: function (transcription) {
                _this.textToSay = '';
                _this.textToSay = transcription.text;
                alert(transcription.text);
            }
        };
    }
    BotComponent.prototype.ngOnInit = function () {
        var id = +this.route.snapshot.params["id"];
        this.question = this.questionService.getQuestion(id);
        this.textToSay = this.question.text;
    };
    BotComponent.prototype.animateJulia = function () {
        var _this = this;
        console.log("Button was pressed");
        var i = 0;
        var speakinterval = setInterval(function () {
            _this.julia = _this.juliaImages[i];
            i++;
            if (i == _this.juliaImages.length)
                clearInterval(speakinterval);
        }, this.timing);
    };
    //text to speech
    BotComponent.prototype.textToSpeech = function () {
        this.animateJulia();
        this.ttsOptions = {
            text: this.textToSay,
            finishedCallback: function (data) {
                console.log(data);
                console.log("i'm done");
            }
        };
        this.tts.speak(this.ttsOptions);
    };
    //sppech to text
    BotComponent.prototype.speechToText = function () {
        var _this = this;
        this.speech.available().then(function (result) { result ? _this.startListening() : alert('Speech recognization is not available'); }, function (err) { console.log(err); });
    };
    BotComponent.prototype.startListening = function () {
        this.speech.startListening(this.speechOptions).then(function () { console.log('started listing'); }, function (err) { console.log(err); });
    };
    BotComponent.prototype.stopListening = function () {
        this.speech.stopListening().then(function () { console.log('stopped listening'); }, function (err) { console.log(err); });
    };
    BotComponent = __decorate([
        core_1.Component({
            selector: "ns-bot",
            moduleId: module.id,
            templateUrl: "./bot.component.html",
        }),
        __metadata("design:paramtypes", [nativescript_texttospeech_1.TNSTextToSpeech,
            nativescript_speech_recognition_1.SpeechRecognition,
            question_service_1.QuestionService,
            router_1.ActivatedRoute])
    ], BotComponent);
    return BotComponent;
}());
exports.BotComponent = BotComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm90LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImJvdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMEM7QUFDMUMsdUVBQTBFO0FBQzFFLG1GQUE2SDtBQUM3SCxvRUFBa0U7QUFFbEUsMENBQWlEO0FBUWpEO0lBU0ksOEVBQThFO0lBQzlFLG9DQUFvQztJQUNwQyxxQkFBcUI7SUFDckIsb0VBQW9FO0lBRXBFLHNCQUNZLEdBQW9CLEVBQ3BCLE1BQXlCLEVBQ3pCLGVBQWdDLEVBQ2hDLEtBQXFCO1FBSmpDLGlCQWNDO1FBYlcsUUFBRyxHQUFILEdBQUcsQ0FBaUI7UUFDcEIsV0FBTSxHQUFOLE1BQU0sQ0FBbUI7UUFDekIsb0JBQWUsR0FBZixlQUFlLENBQWlCO1FBQ2hDLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBaEJqQyxnQkFBVyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsd0JBQXdCLEVBQUUsdUJBQXVCLEVBQUUsdUJBQXVCLEVBQUUsdUJBQXVCLEVBQUUseUJBQXlCLEVBQUUscUJBQXFCLEVBQUUsMEJBQTBCLEVBQUUsMEJBQTBCLEVBQUUsb0JBQW9CLEVBQUUsb0JBQW9CLEVBQUUseUJBQXlCLEVBQUUsZ0JBQWdCLEVBQUUsd0JBQXdCLEVBQUUsMEJBQTBCLEVBQUUsMEJBQTBCLEVBQUUsdUJBQXVCLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUMvYyxXQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ2IsVUFBSyxHQUFHLEVBQUUsQ0FBQztRQWdCUCxJQUFJLENBQUMsYUFBYSxHQUFHO1lBQ3JCLE1BQU0sRUFBRSxPQUFPO1lBQ2YsUUFBUSxFQUFFLFVBQUMsYUFBNkM7Z0JBQ2hELEtBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO2dCQUNwQixLQUFJLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUM7Z0JBQ3BDLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDOUIsQ0FBQztTQUNKLENBQUE7SUFDTCxDQUFDO0lBRUQsK0JBQVEsR0FBUjtRQUNJLElBQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztJQUN4QyxDQUFDO0lBRUQsbUNBQVksR0FBWjtRQUFBLGlCQVFDO1FBUEcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNWLElBQUksYUFBYSxHQUFHLFdBQVcsQ0FBQztZQUM1QixLQUFJLENBQUMsS0FBSyxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsQ0FBQyxFQUFFLENBQUM7WUFDSixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7Z0JBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ25FLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVELGdCQUFnQjtJQUNoQixtQ0FBWSxHQUFaO1FBQ0ksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxVQUFVLEdBQUc7WUFDZCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVM7WUFDcEIsZ0JBQWdCLEVBQUUsVUFBQyxJQUFJO2dCQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzFCLENBQUM7U0FDRixDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxnQkFBZ0I7SUFDaEIsbUNBQVksR0FBWjtRQUFBLGlCQUlDO1FBSEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQ3hCLFVBQUEsTUFBTSxJQUFNLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFBLENBQUMsQ0FBQyxLQUFLLENBQUMsdUNBQXVDLENBQUMsQ0FBQyxDQUFBLENBQUMsRUFDNUYsVUFBQSxHQUFHLElBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLENBQUMsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxxQ0FBYyxHQUFkO1FBQ0ksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FDakQsY0FBUSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQ3pDLFVBQUEsR0FBRyxJQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQzdCLENBQUM7SUFDTixDQUFDO0lBRUQsb0NBQWEsR0FBYjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUM5QixjQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFBLENBQUMsRUFDMUMsVUFBQSxHQUFHLElBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLENBQUMsQ0FDNUIsQ0FBQztJQUNOLENBQUM7SUE5RVEsWUFBWTtRQU54QixnQkFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSxzQkFBc0I7U0FDdEMsQ0FBQzt5Q0FpQm1CLDJDQUFlO1lBQ1osbURBQWlCO1lBQ1Isa0NBQWU7WUFDekIsdUJBQWM7T0FsQnhCLFlBQVksQ0ErRXhCO0lBQUQsbUJBQUM7Q0FBQSxBQS9FRCxJQStFQztBQS9FWSxvQ0FBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IFROU1RleHRUb1NwZWVjaCwgU3BlYWtPcHRpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC10ZXh0dG9zcGVlY2hcIjtcclxuaW1wb3J0IHsgU3BlZWNoUmVjb2duaXRpb24sIFNwZWVjaFJlY29nbml0aW9uVHJhbnNjcmlwdGlvbiwgU3BlZWNoUmVjb2duaXRpb25PcHRpb25zfSBmcm9tIFwibmF0aXZlc2NyaXB0LXNwZWVjaC1yZWNvZ25pdGlvblwiO1xyXG5pbXBvcnQgeyBRdWVzdGlvblNlcnZpY2UgfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvcXVlc3Rpb24uc2VydmljZVwiO1xyXG5pbXBvcnQgeyBRdWVzdGlvbiB9IGZyb20gXCIuLi8uLi9tb2RlbC9xdWVzdGlvblwiO1xyXG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6IFwibnMtYm90XCIsXHJcbiAgICBtb2R1bGVJZDogbW9kdWxlLmlkLFxyXG4gICAgdGVtcGxhdGVVcmw6IFwiLi9ib3QuY29tcG9uZW50Lmh0bWxcIixcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBCb3RDb21wb25lbnQgeyBcclxuXHJcbiAgICBqdWxpYUltYWdlcyA9IFsnanVsaWFfYW5ncnkucG5nJywgJ2p1bGlhX3Rvbmd1ZTJfZnVsbC5wbmcnLCAnanVsaWFfZXllc19jbG9zZWQucG5nJywgJ2p1bGlhX2V5ZXNfY2xvc2UxLnBuZycsICdqdWxpYV9leWVzX2Nsb3NlMi5wbmcnLCAnanVsaWFfZXllc19sb29rbGVmdC5wbmcnLCAnanVsaWFfZXllc19xdWl6LnBuZycsICdqdWxpYV9leWVzX2xvb2tyaWdodC5wbmcnLCAnanVsaWFfbW91dGhfbmFycm93X3cucG5nJywgJ2p1bGlhX2V5ZXNfc2FkLnBuZycsICdqdWxpYV9leWVzX3dvdy5wbmcnLCAnanVsaWFfbW91dGhfbWVkaXVtMS5wbmcnLCAnanVsaWFfZnVsbC5wbmcnLCAnanVsaWFfbW91dGhfY2xvc2VkLnBuZycsICdqdWxpYV9tb3V0aF9uYXJyb3dfby5wbmcnLCAnanVsaWFfbW91dGhfbmFycm93X3UucG5nJywgJ2p1bGlhX21vdXRoX3NtaWxlLnBuZycsICdqdWxpYV9tb3V0aF93aWRlX2YucG5nJ107XHJcbiAgICB0aW1pbmcgPSAyMDA7XHJcbiAgICBqdWxpYSA9ICcnO1xyXG4gICAgdGV4dFRvU2F5OiBzdHJpbmc7XHJcbiAgICB0dHNPcHRpb25zOiBTcGVha09wdGlvbnM7XHJcbiAgICBzcGVlY2hPcHRpb25zOiBTcGVlY2hSZWNvZ25pdGlvbk9wdGlvbnM7XHJcbiAgICBxdWVzdGlvbjogUXVlc3Rpb247XHJcbiAgICAvL2NyZWF0ZSBhbm90aGVyIGNvbnRyb2wgdGhhdCBpbmNyZWFzZXMgb3IgZGNyZWFzZXMgdGhlIHRpbWluZyBhbmQgcGxheXMgYWdhaW5cclxuICAgIC8vbGV0IGluY3JlbWVudCBvciBkZWNyZW1lbnQgYmUgMTBtc1xyXG4gICAgLy9wbGF5IHRoZSBzb3VuZCBhbHNvXHJcbiAgICAvL2ZpbmQgdGhlIHN3ZWV0c3BvdCBhbmQgc2V0IHRoYXQgdmFsdWUuIEFzc3VtZSBzcGVlY2hyYXRlIHRvIGJlIDEuMFxyXG4gICAgXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIHR0czogVE5TVGV4dFRvU3BlZWNoLFxyXG4gICAgICAgIHByaXZhdGUgc3BlZWNoOiBTcGVlY2hSZWNvZ25pdGlvbixcclxuICAgICAgICBwcml2YXRlIHF1ZXN0aW9uU2VydmljZTogUXVlc3Rpb25TZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlXHJcbiAgICAgICAgKXtcclxuICAgICAgICB0aGlzLnNwZWVjaE9wdGlvbnMgPSB7XHJcbiAgICAgICAgbG9jYWxlOiAnZW4tVXMnLFxyXG4gICAgICAgIG9uUmVzdWx0OiAodHJhbnNjcmlwdGlvbjogU3BlZWNoUmVjb2duaXRpb25UcmFuc2NyaXB0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRleHRUb1NheSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50ZXh0VG9TYXkgPSB0cmFuc2NyaXB0aW9uLnRleHQ7XHJcbiAgICAgICAgICAgICAgICBhbGVydCh0cmFuc2NyaXB0aW9uLnRleHQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGlkID0gK3RoaXMucm91dGUuc25hcHNob3QucGFyYW1zW1wiaWRcIl07XHJcbiAgICAgICAgdGhpcy5xdWVzdGlvbiA9IHRoaXMucXVlc3Rpb25TZXJ2aWNlLmdldFF1ZXN0aW9uKGlkKTtcclxuICAgICAgICB0aGlzLnRleHRUb1NheSA9IHRoaXMucXVlc3Rpb24udGV4dDtcclxuICAgIH1cclxuXHJcbiAgICBhbmltYXRlSnVsaWEoKTogdm9pZCB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJCdXR0b24gd2FzIHByZXNzZWRcIik7XHJcbiAgICAgICAgbGV0IGkgPSAwO1xyXG4gICAgICAgIGxldCBzcGVha2ludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4geyBcclxuICAgICAgICAgICAgdGhpcy5qdWxpYSA9IHRoaXMuanVsaWFJbWFnZXNbaV07XHJcbiAgICAgICAgICAgIGkrKztcclxuICAgICAgICAgICAgaWYgKGkgPT0gdGhpcy5qdWxpYUltYWdlcy5sZW5ndGgpIGNsZWFySW50ZXJ2YWwoc3BlYWtpbnRlcnZhbCk7XHJcbiAgICAgICAgfSwgdGhpcy50aW1pbmcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vdGV4dCB0byBzcGVlY2hcclxuICAgIHRleHRUb1NwZWVjaCgpe1xyXG4gICAgICAgIHRoaXMuYW5pbWF0ZUp1bGlhKCk7XHJcbiAgICAgICAgdGhpcy50dHNPcHRpb25zID0ge1xyXG4gICAgICAgICAgICB0ZXh0OiB0aGlzLnRleHRUb1NheSxcclxuICAgICAgICAgICAgZmluaXNoZWRDYWxsYmFjazogKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImknbSBkb25lXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgdGhpcy50dHMuc3BlYWsodGhpcy50dHNPcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICAvL3NwcGVjaCB0byB0ZXh0XHJcbiAgICBzcGVlY2hUb1RleHQoKXtcclxuICAgICAgICB0aGlzLnNwZWVjaC5hdmFpbGFibGUoKS50aGVuKFxyXG4gICAgICAgICAgICByZXN1bHQgPT4geyByZXN1bHQgPyB0aGlzLnN0YXJ0TGlzdGVuaW5nKCk6IGFsZXJ0KCdTcGVlY2ggcmVjb2duaXphdGlvbiBpcyBub3QgYXZhaWxhYmxlJyk7fSxcclxuICAgICAgICAgICAgZXJyID0+IHsgY29uc29sZS5sb2coZXJyKTt9KTtcclxuICAgIH1cclxuXHJcbiAgICBzdGFydExpc3RlbmluZygpe1xyXG4gICAgICAgIHRoaXMuc3BlZWNoLnN0YXJ0TGlzdGVuaW5nKHRoaXMuc3BlZWNoT3B0aW9ucykudGhlbihcclxuICAgICAgICAgICgpID0+IHsgY29uc29sZS5sb2coJ3N0YXJ0ZWQgbGlzdGluZycpOyB9LFxyXG4gICAgICAgICAgZXJyID0+IHsgY29uc29sZS5sb2coZXJyKTsgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RvcExpc3RlbmluZygpe1xyXG4gICAgICAgIHRoaXMuc3BlZWNoLnN0b3BMaXN0ZW5pbmcoKS50aGVuKFxyXG4gICAgICAgICAgKCkgPT4geyBjb25zb2xlLmxvZygnc3RvcHBlZCBsaXN0ZW5pbmcnKTt9LFxyXG4gICAgICAgICAgZXJyID0+IHsgY29uc29sZS5sb2coZXJyKTt9XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxufVxyXG4iXX0=