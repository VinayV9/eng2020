"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var angular_1 = require("nativescript-ui-sidedrawer/angular");
var core_1 = require("@angular/core");
var SideNavComponent = /** @class */ (function () {
    function SideNavComponent() {
    }
    SideNavComponent.prototype.ngOnInit = function () {
        this.items = data;
    };
    SideNavComponent.prototype.toggle = function () {
        this.drawerComponent.sideDrawer.toggleDrawerState();
    };
    SideNavComponent.prototype.onOpenDrawerTap = function () {
        this.drawerComponent.sideDrawer.showDrawer();
    };
    SideNavComponent.prototype.onCloseDrawerTap = function () {
        this.drawerComponent.sideDrawer.closeDrawer();
    };
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent),
        __metadata("design:type", angular_1.RadSideDrawerComponent)
    ], SideNavComponent.prototype, "drawerComponent", void 0);
    SideNavComponent = __decorate([
        core_1.Component({
            selector: "ns-sidenav",
            moduleId: module.id,
            templateUrl: "./sidenav.component.html",
            styles: ["\n    .fa {\n      font-family: FontAwesome, fontawesome-webfont;\n      font-size:20;\n    }\n  "]
        }),
        __metadata("design:paramtypes", [])
    ], SideNavComponent);
    return SideNavComponent;
}());
exports.SideNavComponent = SideNavComponent;
var data = [
    {
        name: "Question1",
        id: 1
    },
    {
        name: "Question2",
        id: 2
    },
    {
        name: "Question3",
        id: 3
    },
    {
        name: "Question4",
        id: 4
    },
    {
        name: "Question5",
        id: 5
    },
    {
        name: "Question6",
        id: 6
    },
    {
        name: "Question7",
        id: 7
    },
    {
        name: "Question8",
        id: 8
    },
    {
        name: "Question9",
        id: 9
    }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lkZW5hdi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzaWRlbmF2LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDhEQUE0RjtBQUM1RixzQ0FBOEQ7QUFjOUQ7SUFLSTtJQUVBLENBQUM7SUFFRCxtQ0FBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7SUFDdEIsQ0FBQztJQUVNLGlDQUFNLEdBQWI7UUFDSSxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQ3hELENBQUM7SUFFRCwwQ0FBZSxHQUFmO1FBQ0ksSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDakQsQ0FBQztJQUVELDJDQUFnQixHQUFoQjtRQUNJLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2xELENBQUM7SUFwQmtDO1FBQWxDLGdCQUFTLENBQUMsZ0NBQXNCLENBQUM7a0NBQXlCLGdDQUFzQjs2REFBQztJQUh6RSxnQkFBZ0I7UUFaNUIsZ0JBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxZQUFZO1lBQ3RCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsMEJBQTBCO1lBQ3ZDLE1BQU0sRUFBRSxDQUFDLG1HQUtWLENBQUM7U0FDSCxDQUFDOztPQUVXLGdCQUFnQixDQXlCNUI7SUFBRCx1QkFBQztDQUFBLEFBekJELElBeUJDO0FBekJZLDRDQUFnQjtBQTJCN0IsSUFBTSxJQUFJLEdBQUc7SUFDVDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7SUFDRDtRQUNJLElBQUksRUFBRSxXQUFXO1FBQ2pCLEVBQUUsRUFBRSxDQUFDO0tBQ1I7Q0FDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmFkU2lkZURyYXdlckNvbXBvbmVudCwgU2lkZURyYXdlclR5cGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXIvYW5ndWxhclwiO1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgIFZpZXdDaGlsZCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiBcIm5zLXNpZGVuYXZcIixcclxuICAgIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgICB0ZW1wbGF0ZVVybDogXCIuL3NpZGVuYXYuY29tcG9uZW50Lmh0bWxcIixcclxuICAgIHN0eWxlczogW2BcclxuICAgIC5mYSB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBGb250QXdlc29tZSwgZm9udGF3ZXNvbWUtd2ViZm9udDtcclxuICAgICAgZm9udC1zaXplOjIwO1xyXG4gICAgfVxyXG4gIGBdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgU2lkZU5hdkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdHsgXHJcblxyXG4gICAgaXRlbXM6IGFueVtdO1xyXG4gICAgQFZpZXdDaGlsZChSYWRTaWRlRHJhd2VyQ29tcG9uZW50KSBwdWJsaWMgZHJhd2VyQ29tcG9uZW50OiBSYWRTaWRlRHJhd2VyQ29tcG9uZW50O1xyXG4gICBcclxuICAgIGNvbnN0cnVjdG9yKCl7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBcclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaXRlbXMgPSBkYXRhO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBwdWJsaWMgdG9nZ2xlKCkge1xyXG4gICAgICAgIHRoaXMuZHJhd2VyQ29tcG9uZW50LnNpZGVEcmF3ZXIudG9nZ2xlRHJhd2VyU3RhdGUoKTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgb25PcGVuRHJhd2VyVGFwKCkge1xyXG4gICAgICAgIHRoaXMuZHJhd2VyQ29tcG9uZW50LnNpZGVEcmF3ZXIuc2hvd0RyYXdlcigpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQ2xvc2VEcmF3ZXJUYXAoKSB7XHJcbiAgICAgICAgdGhpcy5kcmF3ZXJDb21wb25lbnQuc2lkZURyYXdlci5jbG9zZURyYXdlcigpO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuY29uc3QgZGF0YSA9IFtcclxuICAgIHtcclxuICAgICAgICBuYW1lOiBcIlF1ZXN0aW9uMVwiLFxyXG4gICAgICAgIGlkOiAxXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIG5hbWU6IFwiUXVlc3Rpb24yXCIsXHJcbiAgICAgICAgaWQ6IDJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgbmFtZTogXCJRdWVzdGlvbjNcIixcclxuICAgICAgICBpZDogM1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBuYW1lOiBcIlF1ZXN0aW9uNFwiLFxyXG4gICAgICAgIGlkOiA0XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIG5hbWU6IFwiUXVlc3Rpb241XCIsXHJcbiAgICAgICAgaWQ6IDVcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgbmFtZTogXCJRdWVzdGlvbjZcIixcclxuICAgICAgICBpZDogNlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBuYW1lOiBcIlF1ZXN0aW9uN1wiLFxyXG4gICAgICAgIGlkOiA3XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIG5hbWU6IFwiUXVlc3Rpb244XCIsXHJcbiAgICAgICAgaWQ6IDhcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgbmFtZTogXCJRdWVzdGlvbjlcIixcclxuICAgICAgICBpZDogOVxyXG4gICAgfVxyXG5dOyJdfQ==